ELEVARTS — Brand Logos (Wordmark)
==================================

Conține wordmark-ul ELEVARTS în toate variantele cromatice (black, color, white)
și în toate formatele necesare pentru orice tip de utilizare.

STRUCTURĂ
---------
originals/
  vector/   — .ai (Adobe Illustrator) + .eps — pentru print, broderie,
              gravare laser, plottere de tăiere, vinyl
  raster/   — .png (transparență) + .jpg/.jpeg — formatele originale mari
  source/   — .psd (Photoshop) — fișier sursă editabil

web/
  black/    — pentru fundaluri deschise (mono / print / fax)
  color/    — pe fundal alb sau gri foarte deschis
  white/    — pentru fundaluri închise / gradient brand
  fiecare conține wordmark-{80,160,320,480,640,960,1024}.{png,webp}
  PNG = transparență, WEBP = optimizat web (~30-50% mai mic)

REGULI DE FOLOSIRE
------------------
- Wordmark color    → doar pe alb / gri foarte deschis / dark uniform
- Wordmark white    → orice fundal închis (#131120, gradient brand)
- Wordmark black    → mono, print fax, ștampile

CLEAR SPACE        : minimum 16px (web) sau înălțimea literei "E" (print)
DIMENSIUNE MINIMĂ  : 80px lățime web. Sub atât folosește icon-ul.

WEB DELIVERY
------------
Pentru imagini responsive folosește <picture>:
  <picture>
    <source srcset="wordmark-480.webp" type="image/webp">
    <img src="wordmark-480.png" alt="ELEVARTS">
  </picture>

Pentru retina:
  <img srcset="wordmark-320.png 1x, wordmark-640.png 2x" src="wordmark-320.png">

NU
--
- Nu rota, înclina, distorsiona logo-ul
- Nu adăuga drop-shadow, outline, glow
- Nu folosi color logo pe imagini cu compoziție colorată
- Nu redenumi fișierele (rupe link-urile din brand book HTML)

Brand Book v1.0 · 2026 · ask@elevarts.com
