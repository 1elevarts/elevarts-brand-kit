ELEVARTS — Brand Icons (Symbol "V")
====================================

Conține icon-ul ELEVARTS (simbolul "V" stilizat) — folosit când spațiul nu
permite wordmark-ul lizibil: favicon, app icons, social profile pictures,
sidebar nav, broderie pe tricouri.

STRUCTURĂ
---------
originals/
  icon-master.svg         — master vectorial (color)
  icon-master-color.svg   — variantă color (gradient brand)
  icon-master-black.svg   — variantă mono black
  icon-master-white.svg   — variantă mono white
  Format SVG = scalabil infinit, ideal pentru web modern, print, broderie.

web/
  black/  — pentru fundaluri deschise / mono
  color/  — pentru fundaluri albe / gri deschis
  white/  — pentru fundaluri închise / gradient brand
  fiecare conține icon-{16,32,64,128,192,256,512}.{png,webp}
  PNG = transparență, WEBP = optimizat web (~30-50% mai mic)

favicon/
  favicon.ico             — multi-size .ico clasic (16/32/48)
  apple-touch-icon.png    — 180×180 pentru iOS home screen
  manifest.json           — PWA manifest cu maskable icons

REGULI
------
- DIMENSIUNE MINIMĂ: 16px. Sub atât nu mai e lizibil.
- Profile picture social: icon color pe fundal dark (#131120) — cel mai bun
  contrast pe profil rotund. Niciodată wordmark tăiat în cerc.
- Pentru SVG inline pe web preferă icon-master-color.svg (singurul fișier
  necesar la mărimi multiple).

INTEGRARE FAVICON (HTML <head>)
-------------------------------
  <link rel="icon" href="/favicon.ico" sizes="any">
  <link rel="icon" type="image/svg+xml" href="/icon-master-color.svg">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link rel="manifest" href="/manifest.json">

Brand Book v1.0 · 2026 · ask@elevarts.com
