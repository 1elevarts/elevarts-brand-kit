ELEVARTS — Brand Fonts
========================

Conține familiile de fonturi oficiale ELEVARTS.

ATENȚIE — fonturile sunt licențiate. A se folosi DOAR în materiale ELEVARTS
(echipa internă, parteneri, designeri freelance contractați pentru proiecte ELEVARTS).
Nu redistribui către terți care nu lucrează la materiale ELEVARTS.

STRUCTURĂ
---------
Euclid-Flex/        — familia completă Euclid Flex (display, headlines)
                      14 weight-uri + italice, format .otf
Gotham/             — familia completă Gotham (body, UI)
                      .otf + .ttf, multiple weight-uri
web-ready/          — variantele subset folosite efectiv în brand book HTML
                      (gata de @font-face, file size mai mic)

INSTALARE LOCAL
---------------
macOS    : dublu-click pe fiecare fișier → Install Font, sau drop în Font Book
Windows  : right-click → Install for all users
Linux    : copy în ~/.local/share/fonts/ și rulează `fc-cache -f -v`

INTEGRARE WEB
-------------
Pentru proiecte web folosește fișierele din web-ready/ cu @font-face.
Vezi exemplul din elevarts-brand-book.html (secțiunea <style>) pentru
declarațiile @font-face oficiale (font-family, font-weight, src).

REGULĂ TIPOGRAFIE
-----------------
- Euclid Flex   = display, headlines (h1..h4)
- Gotham        = body, UI, butoane, captions
- Niciodată system fonts (Inter, SF Pro, Helvetica) pe materiale ELEVARTS.

Brand Book v1.0 · 2026 · ask@elevarts.com
