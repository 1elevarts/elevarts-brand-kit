Water Brush — Keywords / Highlight Accent
Designer: Rob Leuschke (TypeSETit)
Licență: SIL Open Font License (OFL) v1.1 — free pentru commercial use
Sursa: https://fonts.google.com/specimen/Water+Brush

Folosește pentru cuvinte cheie evidențiate, citate scurte, semnături emoționale, titluri evenimente speciale.
NU folosi pe paragrafe lungi sau body text — e font script display.

Brand book: https://[subdomain].elevarts.ro/
