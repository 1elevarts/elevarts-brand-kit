ELEVARTS — All Logo Variants

Conținut:
  Ai/        master Adobe Illustrator (toate variantele)
  Png/       PNG transparent (toate variantele)
  Jpg/       JPEG (toate variantele + auxiliare)
  Psd/       Photoshop master
  web-wordmark/   versiuni optimizate web (color/black/white × multiple sizes, PNG+WebP)

Brand book: https://[subdomain].elevarts.ro/
Contact: ask@elevarts.com
