ELEVARTS — All Icon Variants

web/color/, web/black/, web/white/   PNG+WebP 16-512px (logo standalone, transparent bg)
favicon/                             App-icon style (cerc alb + margine mov + logo color) pentru tab/home screen
svg/                                  Master SVGs

Brand book: https://brand.elevarts.ro/
