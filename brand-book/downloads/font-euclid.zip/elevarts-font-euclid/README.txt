Euclid Flex — Display / Headlines
Folosește pentru titluri, hero, navigation principal, brand statements.
14 weights disponibile (Thin → Bold + Italic).

Licență: comercial — utilizare licențiată Elevarts. NU redistribui.
Brand book: https://[subdomain].elevarts.ro/
