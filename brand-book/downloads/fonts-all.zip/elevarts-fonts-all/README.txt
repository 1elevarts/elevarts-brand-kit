ELEVARTS — All Fonts

Conținut:
  Euclid Family/      Display / Headlines (14 weights)
  Gotham Family/      Body / UI (17 variante)
  Lonally Qoma/       Keywords / Highlight Accent (primary script)
  Water Brush/        Web fallback pentru Lonally (OFL Google Fonts)

Pairing rules:
- eyebrow = Gotham 500 uppercase 0.22em
- headline = Euclid Flex 600/700
- accent emoțional (1 cuvânt) = Lonally Qoma (sau Water Brush online)
- body = Gotham 400
- CTA = Gotham 500 uppercase 0.08em

Brand book: https://brand.elevarts.ro/
