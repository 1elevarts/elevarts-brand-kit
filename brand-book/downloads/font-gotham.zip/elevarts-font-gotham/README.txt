Gotham — Body / UI
Folosește pentru paragrafe, navigation secundar, etichete, butoane, formulare.
17 weights/variante (Thin/Light/Book/Medium/Bold/Black + Italic).

Licență: comercial — utilizare licențiată Elevarts. NU redistribui.
Brand book: https://[subdomain].elevarts.ro/
