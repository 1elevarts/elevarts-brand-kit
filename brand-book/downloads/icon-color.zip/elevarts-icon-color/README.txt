ELEVARTS — Icon Color (wordmark VA original)
Forma + culorile naturale extrase pixel-perfect din wordmark color (hi-res master 2171x2171).
icon-color-master.png  master full-resolution
web/                   PNG + WebP la 16-512 px (LANCZOS resampled)
Brand book: https://brand.elevarts.ro/
