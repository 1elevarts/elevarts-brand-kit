ELEVARTS — Icon white
Forma + culorile naturale extrase pixel-perfect din wordmark color.
Brand book: https://brand.elevarts.ro/
