Lonally Qoma — Keywords / Highlight Accent
Folosește pentru cuvinte cheie evidențiate emoțional, semnături manuscrise, titluri evenimente speciale.

Reguli stricte:
- Max 1 cuvânt Lonally într-o compoziție
- Min 32px (sub 32px ilizibil)
- Doar pe primary purple/magenta sau dark — niciodată pe secondary colors
- NU pe paragraf, NU pe button, NU pe meniu

Pentru web extern unde nu poate fi încărcat fontul, fallback la Water Brush (Google Fonts).

Brand book: https://brand.elevarts.ro/
